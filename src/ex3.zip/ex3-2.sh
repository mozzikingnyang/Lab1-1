#!/bin/sh

read num1 operator num2

case $operator in
    "+")
        result=$(expr $num1 + $num2)
        ;;
    "-")
        result=$(expr $num1 - $num2)
        ;;
esac

echo $result

exit 0
