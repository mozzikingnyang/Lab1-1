#!/bin/sh

read weight height

res=$(echo "scale=2; $weight / ($height * $height)" | bc)

# Compare and print the result
if [ $(echo "$res < 18.5" | bc) -eq 1 ]; then
    echo "저체중입니다."
elif [ $(echo "$res >= 23" | bc) -eq 1 ]; then
    echo "과체중입니다."
else
    echo "정상체중입니다."
fi

exit 0
