#!/bin/sh

myFunction() {
  local command="$1"
  echo "함수 안으로 들어왔음"
  echo "실행할 명령어: $command"
  eval "$command"
}

echo "프로그램을 시작합니다."
myFunction "ls -l"  # Replace "ls -l" with the desired Linux command
echo "프로그램을 종료합니다."
exit 0

