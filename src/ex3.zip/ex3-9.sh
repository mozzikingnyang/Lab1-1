#!/bin/bash

db_file="DB.txt"

# DB.txt 파일이 없으면 생성
[ ! -e "$db_file" ] && touch "$db_file"

read -p "찾고자 하는 팀원의 이름을 입력하세요: " search_name

# DB.txt 파일에서 해당 이름이 포함된 줄 출력
if grep -q "$search_name" "$db_file"; then
  grep "$search_name" "$db_file"
else
  echo "해당하는 팀원이 DB에 없습니다."
fi

