#!/bin/sh

read -p "폴더 이름을 입력하세요: " foldername

if [ -d "$foldername" ]; then
  echo "이미 존재하는 폴더입니다."
else
  echo "$foldername 폴더가 존재하지 않습니다. 새로운 폴더를 생성하고 파일 5개를 만들어 각 파일에 대한 하위 폴더를 생성하고 파일을 해당 폴더에 이동합니다."

  # Create the main folder
  mkdir "$foldername"

  # Change to the main folder directory
  cd "$foldername" || exit

  # Create five files and corresponding subfolders
  for i in {1..5}; do
    touch file${i}.txt
    subfoldername="폴더_${i}"

    echo "This is $filename" > "$filename"

    # Create a subfolder named after each file and move the file into the subfolder
    mkdir "$subfoldername"
    mv "$filename" "$subfoldername/"
  done

  echo "폴더 생성, 파일 5개 생성, 각 파일에 대한 하위 폴더 생성 및 파일 이동이 완료되었습니다."
fi

exit 0

