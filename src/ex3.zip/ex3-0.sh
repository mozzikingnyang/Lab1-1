#!/bin/sh
echo "hello world"
exit 0
