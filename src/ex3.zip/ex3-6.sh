#!/bin/bash

read -p "폴더 이름을 입력하세요: " folder_name

# 폴더가 없으면 생성
if [ ! -d "$folder_name" ]; then
  mkdir "$folder_name"
fi

# 폴더로 이동
cd "$folder_name" || exit

# 5개의 텍스트 파일 생성
for i in {1..5}; do
  touch "file${i}.txt"
  echo "This is $filename" > "$filename"
done

# 폴더 내 파일들을 압축
zip -r "$folder_name.zip" ./*

echo "폴더 생성, 파일 5개 생성, 압축이 완료되었습니다."

