#!/bin/bash

db_file="DB.txt"

# DB.txt 파일이 없으면 생성
[ ! -e "$db_file" ] && touch "$db_file"

read -p "팀원의 정보를 입력하세요 (이름 생일 형식): " input

# 입력 받은 정보를 DB.txt 파일에 기록
echo "$input" >> "$db_file"

echo "팀원 정보가 성공적으로 기록되었습니다."

