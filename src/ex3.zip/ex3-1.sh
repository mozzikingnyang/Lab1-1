#!/bin/sh
read a

yes "hello world" | head -n $a

 exit 0
